[CmdletBinding()]
param(
    [ValidateSet("gui", "start", "stop", "status", "monitor", "list-apps")]
    [string]$Command = "gui",

    [ValidateRange(1, 240)]
    [int]$Minutes = 25,

    [switch]$HardBlock,

    [string]$Apps = "steam"
)

$ErrorActionPreference = "Stop"
$ConfigPath = Join-Path $PSScriptRoot "config.json"
$StatePath = Join-Path $PSScriptRoot "state.json"

function Get-Config {
    if (-not (Test-Path $ConfigPath)) {
        throw "Missing config.json beside this script."
    }

    return (Get-Content -Path $ConfigPath -Raw | ConvertFrom-Json)
}

function Save-Config($Config) {
    $Config | ConvertTo-Json -Depth 12 | Set-Content -Path $ConfigPath -Encoding UTF8
}

function Get-ApplicationId([string]$Label, [object[]]$ExistingApplications) {
    $id = [regex]::Replace($Label.ToLowerInvariant(), "[^a-z0-9]+", "-").Trim("-")
    if (-not $id) {
        $id = "custom-app"
    }

    $baseId = $id
    $suffix = 2
    while (@($ExistingApplications | Where-Object { $_.id -eq $id }).Count -gt 0) {
        $id = "$baseId-$suffix"
        $suffix += 1
    }

    return $id
}

function Get-State {
    if (-not (Test-Path $StatePath)) {
        return [pscustomobject]@{
            active = $false
            hardBlock = $false
            startedAt = $null
            endsAt = $null
            applicationIds = @()
        }
    }

    return (Get-Content -Path $StatePath -Raw | ConvertFrom-Json)
}

function Save-State($State) {
    $State | ConvertTo-Json -Depth 8 | Set-Content -Path $StatePath -Encoding UTF8
}

function Clear-State {
    Save-State ([pscustomobject]@{
            active = $false
            hardBlock = $false
            startedAt = $null
            endsAt = $null
            applicationIds = @()
        })
}

function Get-ApplicationById([string]$Id) {
    $config = Get-Config
    return @($config.applications | Where-Object { $_.id -eq $Id })[0]
}

function Get-SelectedApplicationIds([string]$Value) {
    $config = Get-Config
    $ids = @($Value.Split(",") | ForEach-Object { $_.Trim().ToLowerInvariant() } | Where-Object { $_ })
    if ($ids.Count -eq 0) {
        throw "Choose at least one application ID."
    }

    foreach ($id in $ids) {
        $application = Get-ApplicationById $id
        if ($null -eq $application) {
            throw "Unknown application ID '$id'. Use -Command list-apps to see available IDs."
        }
    }

    return $ids
}

function Get-ProcessNames([object[]]$ApplicationIds) {
    $names = New-Object System.Collections.Generic.List[string]
    foreach ($id in @($ApplicationIds)) {
        $application = Get-ApplicationById ([string]$id)
        if ($null -eq $application) {
            continue
        }

        foreach ($name in @($application.processNames)) {
            if (-not $names.Contains([string]$name)) {
                $names.Add([string]$name)
            }
        }
    }

    return @($names)
}

function Stop-BlockedProcesses([object[]]$ApplicationIds) {
    $processNames = Get-ProcessNames $ApplicationIds
    foreach ($name in $processNames) {
        $processes = @(Get-Process -Name $name -ErrorAction SilentlyContinue)
        foreach ($process in $processes) {
            try {
                Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
                Write-Host "Closed $name (PID $($process.Id))." -ForegroundColor DarkYellow
            }
            catch {
                Write-Host "Could not close $name (PID $($process.Id)). Try running the launcher as administrator." -ForegroundColor Red
            }
        }
    }
}

function Get-SessionEnd($State) {
    if (-not $State.active -or -not $State.endsAt) {
        return $null
    }

    return ([DateTime]::Parse([string]$State.endsAt)).ToUniversalTime()
}

function Test-SessionExpired($State) {
    $end = Get-SessionEnd $State
    return ($null -ne $end -and $end -le [DateTime]::UtcNow)
}

function Start-Session([int]$DurationMinutes, [bool]$IsHardBlock, [string]$ApplicationValue) {
    $current = Get-State
    if ($current.active -and -not (Test-SessionExpired $current)) {
        throw "A desktop focus session is already active."
    }

    $applicationIds = Get-SelectedApplicationIds $ApplicationValue
    $now = [DateTime]::UtcNow
    $ends = $now.AddMinutes($DurationMinutes)
    $state = [pscustomobject]@{
        active = $true
        hardBlock = $IsHardBlock
        startedAt = $now.ToString("o")
        endsAt = $ends.ToString("o")
        applicationIds = @($applicationIds)
    }

    Save-State $state
    Write-Host ""
    Write-Host "Desktop focus session started." -ForegroundColor Green
    Write-Host "Applications: $($applicationIds -join ', ')"
    Write-Host "Ends: $($ends.ToLocalTime().ToString('g'))"
    if ($IsHardBlock) {
        Write-Host "Hard block is ON. Press S only after the timer expires." -ForegroundColor Yellow
    }
    Write-Host "The monitor window must remain open for enforcement." -ForegroundColor DarkGray
    Monitor-Session
}

function Stop-Session {
    $state = Get-State
    if (-not $state.active -or (Test-SessionExpired $state)) {
        Clear-State
        Write-Host "No active desktop focus session."
        return
    }

    if ($state.hardBlock) {
        throw "Hard block is active. This session cannot end early."
    }

    Clear-State
    Write-Host "Desktop focus session ended." -ForegroundColor Green
}

function Monitor-Session {
    while ($true) {
        $state = Get-State
        if (-not $state.active) {
            return
        }

        if (Test-SessionExpired $state) {
            Clear-State
            Write-Host ""
            Write-Host "Desktop focus session complete. Applications are unlocked." -ForegroundColor Green
            return
        }

        Stop-BlockedProcesses @($state.applicationIds)
        $end = Get-SessionEnd $state
        $remaining = $end - [DateTime]::UtcNow
        $remainingText = "{0:00}:{1:00}" -f [Math]::Floor($remaining.TotalMinutes), $remaining.Seconds
        Write-Host ("Active | {0} remaining | {1}" -f $remainingText, ($state.applicationIds -join ", ")) -ForegroundColor Cyan

        try {
            if ([Console]::KeyAvailable) {
                $key = [Console]::ReadKey($true)
                if ($key.Key -eq [ConsoleKey]::S) {
                    if ($state.hardBlock) {
                        Write-Host "Hard block is locked until $($end.ToLocalTime().ToString('g'))." -ForegroundColor Yellow
                    }
                    else {
                        Clear-State
                        Write-Host "Desktop focus session ended." -ForegroundColor Green
                        return
                    }
                }
            }
        }
        catch {
            # Key input is unavailable when the script is launched without an interactive console.
        }

        $config = Get-Config
        $pollSeconds = [Math]::Max(1, [int]$config.pollIntervalSeconds)
        Start-Sleep -Seconds $pollSeconds
    }
}

function Show-Status {
    $state = Get-State
    if (-not $state.active -or (Test-SessionExpired $state)) {
        if ($state.active) {
            Clear-State
        }
        Write-Host "No active desktop focus session."
        return
    }

    $end = Get-SessionEnd $state
    Write-Host "Desktop focus session: ACTIVE" -ForegroundColor Green
    Write-Host "Mode: $(if ($state.hardBlock) { 'HARD BLOCK' } else { 'Normal' })"
    Write-Host "Ends: $($end.ToLocalTime().ToString('g'))"
    Write-Host "Applications: $($state.applicationIds -join ', ')"
}

function Show-Applications {
    $config = Get-Config
    Write-Host "Available application presets:" -ForegroundColor Cyan
    foreach ($application in @($config.applications)) {
        Write-Host ("  {0,-12} {1,-24} processes: {2}" -f $application.id, $application.label, ($application.processNames -join ", "))
    }
    Write-Host ""
    Write-Host "Use the graphical window's Add application button to add a custom program."
}

function Show-Gui {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $config = Get-Config
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Focus Desktop Guard"
    $form.Size = New-Object System.Drawing.Size(560, 650)
    $form.MinimumSize = New-Object System.Drawing.Size(560, 650)
    $form.StartPosition = "CenterScreen"
    $form.MaximizeBox = $false
    $form.FormBorderStyle = "FixedDialog"
    $form.BackColor = [System.Drawing.Color]::FromArgb(247, 249, 252)

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "Focus Desktop Guard"
    $title.Font = New-Object System.Drawing.Font("Segoe UI", 18, [System.Drawing.FontStyle]::Bold)
    $title.ForeColor = [System.Drawing.Color]::FromArgb(24, 38, 61)
    $title.Location = New-Object System.Drawing.Point(28, 20)
    $title.AutoSize = $true
    $form.Controls.Add($title)

    $subtitle = New-Object System.Windows.Forms.Label
    $subtitle.Text = "Block distracting Windows apps during a focus session."
    $subtitle.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $subtitle.ForeColor = [System.Drawing.Color]::FromArgb(91, 105, 125)
    $subtitle.Location = New-Object System.Drawing.Point(30, 55)
    $subtitle.AutoSize = $true
    $form.Controls.Add($subtitle)

    $sessionBox = New-Object System.Windows.Forms.GroupBox
    $sessionBox.Text = "Session"
    $sessionBox.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $sessionBox.Location = New-Object System.Drawing.Point(28, 88)
    $sessionBox.Size = New-Object System.Drawing.Size(244, 178)
    $form.Controls.Add($sessionBox)

    $minutesLabel = New-Object System.Windows.Forms.Label
    $minutesLabel.Text = "Duration (minutes)"
    $minutesLabel.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $minutesLabel.Location = New-Object System.Drawing.Point(18, 32)
    $minutesLabel.AutoSize = $true
    $sessionBox.Controls.Add($minutesLabel)

    $minutes = New-Object System.Windows.Forms.NumericUpDown
    $minutes.Minimum = 1
    $minutes.Maximum = 240
    $minutes.Value = 25
    $minutes.Width = 70
    $minutes.Location = New-Object System.Drawing.Point(18, 56)
    $minutes.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $sessionBox.Controls.Add($minutes)

    $normal = New-Object System.Windows.Forms.RadioButton
    $normal.Text = "Normal - can end early"
    $normal.Location = New-Object System.Drawing.Point(18, 94)
    $normal.AutoSize = $true
    $normal.Checked = $true
    $normal.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $sessionBox.Controls.Add($normal)

    $hard = New-Object System.Windows.Forms.RadioButton
    $hard.Text = "Hard block - locked timer"
    $hard.Location = New-Object System.Drawing.Point(18, 124)
    $hard.AutoSize = $true
    $hard.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $sessionBox.Controls.Add($hard)

    $appsBox = New-Object System.Windows.Forms.GroupBox
    $appsBox.Text = "Apps to block"
    $appsBox.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $appsBox.Location = New-Object System.Drawing.Point(288, 88)
    $appsBox.Size = New-Object System.Drawing.Size(244, 178)
    $form.Controls.Add($appsBox)

    $appsList = New-Object System.Windows.Forms.CheckedListBox
    $appsList.Location = New-Object System.Drawing.Point(14, 27)
    $appsList.Size = New-Object System.Drawing.Size(214, 103)
    $appsList.CheckOnClick = $true
    $appsList.SelectionMode = "One"
    $appsList.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $appsList.DisplayMember = "label"
    foreach ($application in @($config.applications)) {
        [void]$appsList.Items.Add($application, ($application.id -eq "steam"))
    }
    $appsBox.Controls.Add($appsList)

    $addAppButton = New-Object System.Windows.Forms.Button
    $addAppButton.Text = "Add application"
    $addAppButton.Location = New-Object System.Drawing.Point(14, 135)
    $addAppButton.Size = New-Object System.Drawing.Size(102, 27)
    $addAppButton.BackColor = [System.Drawing.Color]::White
    $addAppButton.FlatStyle = "Flat"
    $addAppButton.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $appsBox.Controls.Add($addAppButton)

    $removeAppButton = New-Object System.Windows.Forms.Button
    $removeAppButton.Text = "Remove custom"
    $removeAppButton.Location = New-Object System.Drawing.Point(126, 135)
    $removeAppButton.Size = New-Object System.Drawing.Size(102, 27)
    $removeAppButton.BackColor = [System.Drawing.Color]::White
    $removeAppButton.FlatStyle = "Flat"
    $removeAppButton.Font = New-Object System.Drawing.Font("Segoe UI", 8)
    $appsBox.Controls.Add($removeAppButton)

    $statusBox = New-Object System.Windows.Forms.GroupBox
    $statusBox.Text = "Status"
    $statusBox.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $statusBox.Location = New-Object System.Drawing.Point(28, 282)
    $statusBox.Size = New-Object System.Drawing.Size(504, 104)
    $form.Controls.Add($statusBox)

    $status = New-Object System.Windows.Forms.Label
    $status.Text = "No active session"
    $status.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
    $status.ForeColor = [System.Drawing.Color]::FromArgb(91, 105, 125)
    $status.Location = New-Object System.Drawing.Point(18, 27)
    $status.AutoSize = $true
    $statusBox.Controls.Add($status)

    $countdown = New-Object System.Windows.Forms.Label
    $countdown.Text = "Choose your apps and start a session."
    $countdown.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $countdown.ForeColor = [System.Drawing.Color]::FromArgb(91, 105, 125)
    $countdown.Location = New-Object System.Drawing.Point(19, 57)
    $countdown.AutoSize = $true
    $statusBox.Controls.Add($countdown)

    $startButton = New-Object System.Windows.Forms.Button
    $startButton.Text = "Start session"
    $startButton.Location = New-Object System.Drawing.Point(28, 404)
    $startButton.Size = New-Object System.Drawing.Size(158, 40)
    $startButton.BackColor = [System.Drawing.Color]::FromArgb(31, 112, 214)
    $startButton.ForeColor = [System.Drawing.Color]::White
    $startButton.FlatStyle = "Flat"
    $startButton.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $form.Controls.Add($startButton)

    $stopButton = New-Object System.Windows.Forms.Button
    $stopButton.Text = "End normal session"
    $stopButton.Location = New-Object System.Drawing.Point(198, 404)
    $stopButton.Size = New-Object System.Drawing.Size(158, 40)
    $stopButton.BackColor = [System.Drawing.Color]::White
    $stopButton.ForeColor = [System.Drawing.Color]::FromArgb(24, 38, 61)
    $stopButton.FlatStyle = "Flat"
    $stopButton.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $form.Controls.Add($stopButton)

    $refreshButton = New-Object System.Windows.Forms.Button
    $refreshButton.Text = "Refresh status"
    $refreshButton.Location = New-Object System.Drawing.Point(368, 404)
    $refreshButton.Size = New-Object System.Drawing.Size(164, 40)
    $refreshButton.BackColor = [System.Drawing.Color]::White
    $refreshButton.ForeColor = [System.Drawing.Color]::FromArgb(24, 38, 61)
    $refreshButton.FlatStyle = "Flat"
    $refreshButton.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $form.Controls.Add($refreshButton)

    $log = New-Object System.Windows.Forms.TextBox
    $log.Multiline = $true
    $log.ReadOnly = $true
    $log.ScrollBars = "Vertical"
    $log.Location = New-Object System.Drawing.Point(28, 464)
    $log.Size = New-Object System.Drawing.Size(504, 112)
    $log.BackColor = [System.Drawing.Color]::White
    $log.Font = New-Object System.Drawing.Font("Consolas", 8.5)
    $form.Controls.Add($log)

    function Write-GuiLog([string]$Message) {
        $log.AppendText(("{0}  {1}{2}" -f (Get-Date).ToString("HH:mm:ss"), $Message, [Environment]::NewLine))
    }

    function Refresh-AppList([string[]]$CheckedIds) {
        $currentConfig = Get-Config
        $appsList.Items.Clear()
        foreach ($application in @($currentConfig.applications)) {
            $shouldCheck = $CheckedIds -contains [string]$application.id
            [void]$appsList.Items.Add($application, $shouldCheck)
        }
    }

    function Update-GuiStatus {
        $state = Get-State
        if (-not $state.active) {
            $status.Text = "No active session"
            $status.ForeColor = [System.Drawing.Color]::FromArgb(91, 105, 125)
            $countdown.Text = "Choose your apps and start a session."
            $startButton.Enabled = $true
            $stopButton.Enabled = $false
            $addAppButton.Enabled = $true
            $removeAppButton.Enabled = $true
            return
        }

        if (Test-SessionExpired $state) {
            Clear-State
            $status.Text = "Session complete"
            $status.ForeColor = [System.Drawing.Color]::FromArgb(31, 135, 83)
            $countdown.Text = "Your selected apps are unlocked."
            $startButton.Enabled = $true
            $stopButton.Enabled = $false
            $addAppButton.Enabled = $true
            $removeAppButton.Enabled = $true
            Write-GuiLog "Session complete. Apps are unlocked."
            return
        }

        $end = Get-SessionEnd $state
        $remaining = $end - [DateTime]::UtcNow
        $remainingText = "{0:00}:{1:00}" -f [Math]::Floor($remaining.TotalMinutes), $remaining.Seconds
        $modeText = if ($state.hardBlock) { "HARD BLOCK" } else { "NORMAL" }
        $status.Text = "Session active - $modeText"
        $status.ForeColor = [System.Drawing.Color]::FromArgb(196, 115, 18)
        $countdown.Text = "$remainingText remaining  |  Apps: $($state.applicationIds -join ', ')"
        $startButton.Enabled = $false
        $stopButton.Enabled = -not [bool]$state.hardBlock
        $addAppButton.Enabled = $false
        $removeAppButton.Enabled = $false
        if ($state.hardBlock) {
            $stopButton.Text = "Locked until timer ends"
        }
        else {
            $stopButton.Text = "End normal session"
        }
    }

    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = [Math]::Max(1000, ([int]$config.pollIntervalSeconds * 1000))
    $timer.Add_Tick({
        try {
            $state = Get-State
            if ($state.active -and (Test-SessionExpired $state)) {
                Clear-State
                Write-GuiLog "Session complete. Apps are unlocked."
            }
            elseif ($state.active) {
                Stop-BlockedProcesses @($state.applicationIds)
            }
            Update-GuiStatus
        }
        catch {
            Write-GuiLog "Monitor error: $($_.Exception.Message)"
        }
    })

    $addAppButton.Add_Click({
        try {
            $addForm = New-Object System.Windows.Forms.Form
            $addForm.Text = "Add application"
            $addForm.Size = New-Object System.Drawing.Size(520, 245)
            $addForm.StartPosition = "CenterParent"
            $addForm.FormBorderStyle = "FixedDialog"
            $addForm.MaximizeBox = $false
            $addForm.MinimizeBox = $false

            $nameLabel = New-Object System.Windows.Forms.Label
            $nameLabel.Text = "Application name"
            $nameLabel.Location = New-Object System.Drawing.Point(22, 20)
            $nameLabel.AutoSize = $true
            $addForm.Controls.Add($nameLabel)

            $nameInput = New-Object System.Windows.Forms.TextBox
            $nameInput.Location = New-Object System.Drawing.Point(22, 43)
            $nameInput.Size = New-Object System.Drawing.Size(450, 24)
            $addForm.Controls.Add($nameInput)

            $fileLabel = New-Object System.Windows.Forms.Label
            $fileLabel.Text = "Program file (.exe)"
            $fileLabel.Location = New-Object System.Drawing.Point(22, 78)
            $fileLabel.AutoSize = $true
            $addForm.Controls.Add($fileLabel)

            $fileInput = New-Object System.Windows.Forms.TextBox
            $fileInput.Location = New-Object System.Drawing.Point(22, 101)
            $fileInput.Size = New-Object System.Drawing.Size(350, 24)
            $fileInput.ReadOnly = $true
            $addForm.Controls.Add($fileInput)

            $browseButton = New-Object System.Windows.Forms.Button
            $browseButton.Text = "Browse..."
            $browseButton.Location = New-Object System.Drawing.Point(380, 99)
            $browseButton.Size = New-Object System.Drawing.Size(92, 28)
            $addForm.Controls.Add($browseButton)

            $saveAppButton = New-Object System.Windows.Forms.Button
            $saveAppButton.Text = "Add application"
            $saveAppButton.Location = New-Object System.Drawing.Point(252, 157)
            $saveAppButton.Size = New-Object System.Drawing.Size(120, 32)
            $addForm.Controls.Add($saveAppButton)

            $cancelAppButton = New-Object System.Windows.Forms.Button
            $cancelAppButton.Text = "Cancel"
            $cancelAppButton.Location = New-Object System.Drawing.Point(380, 157)
            $cancelAppButton.Size = New-Object System.Drawing.Size(92, 32)
            $cancelAppButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
            $addForm.Controls.Add($cancelAppButton)
            $addForm.CancelButton = $cancelAppButton

            $browseButton.Add_Click({
                $fileDialog = New-Object System.Windows.Forms.OpenFileDialog
                $fileDialog.Title = "Choose the program to block"
                $fileDialog.Filter = "Programs (*.exe)|*.exe|All files (*.*)|*.*"
                $fileDialog.CheckFileExists = $true
                if ($fileDialog.ShowDialog($addForm) -eq [System.Windows.Forms.DialogResult]::OK) {
                    $fileInput.Text = $fileDialog.FileName
                    if (-not $nameInput.Text) {
                        $nameInput.Text = [System.IO.Path]::GetFileNameWithoutExtension($fileDialog.FileName)
                    }
                }
                $fileDialog.Dispose()
            })

            $saveAppButton.Add_Click({
                if (-not $fileInput.Text) {
                    [System.Windows.Forms.MessageBox]::Show("Choose a .exe file first.", "Choose a program", "OK", "Warning")
                    return
                }

                $label = $nameInput.Text.Trim()
                if (-not $label) {
                    $label = [System.IO.Path]::GetFileNameWithoutExtension($fileInput.Text)
                }

                $currentConfig = Get-Config
                $processName = [System.IO.Path]::GetFileNameWithoutExtension($fileInput.Text)
                $newApplication = [pscustomobject]@{
                    id = Get-ApplicationId $label @($currentConfig.applications)
                    label = $label
                    processNames = @($processName)
                    custom = $true
                }
                $currentConfig.applications = @($currentConfig.applications) + $newApplication
                Save-Config $currentConfig
                Refresh-AppList @($newApplication.id)
                Write-GuiLog "Added $label ($processName.exe)."
                $addForm.Close()
            })

            [void]$addForm.ShowDialog($form)
            $addForm.Dispose()
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, "Could not add application", "OK", "Error")
        }
    })

    $removeAppButton.Add_Click({
        try {
            $selectedApplication = $appsList.SelectedItem
            if ($null -eq $selectedApplication) {
                [System.Windows.Forms.MessageBox]::Show("Select a custom application first.", "Remove application", "OK", "Warning")
                return
            }
            if (-not [bool]$selectedApplication.custom) {
                [System.Windows.Forms.MessageBox]::Show("Built-in presets cannot be removed.", "Remove application", "OK", "Information")
                return
            }

            $answer = [System.Windows.Forms.MessageBox]::Show("Remove '$($selectedApplication.label)' from the app list?", "Remove application", "YesNo", "Question")
            if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
                return
            }

            $currentConfig = Get-Config
            $currentConfig.applications = @($currentConfig.applications | Where-Object { $_.id -ne $selectedApplication.id })
            Save-Config $currentConfig
            Refresh-AppList @("steam")
            Write-GuiLog "Removed $($selectedApplication.label)."
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, "Could not remove application", "OK", "Error")
        }
    })

    $startButton.Add_Click({
        try {
            $current = Get-State
            if ($current.active -and -not (Test-SessionExpired $current)) {
                [System.Windows.Forms.MessageBox]::Show("A session is already active.", "Focus Desktop Guard", "OK", "Information")
                return
            }

            $selectedApps = @($appsList.CheckedItems | ForEach-Object { [string]$_.id })
            if ($selectedApps.Count -eq 0) {
                [System.Windows.Forms.MessageBox]::Show("Select at least one app to block.", "Choose an app", "OK", "Warning")
                return
            }

            $now = [DateTime]::UtcNow
            $ends = $now.AddMinutes([int]$minutes.Value)
            $isHardBlock = [bool]$hard.Checked
            Save-State ([pscustomobject]@{
                    active = $true
                    hardBlock = $isHardBlock
                    startedAt = $now.ToString("o")
                    endsAt = $ends.ToString("o")
                    applicationIds = @($selectedApps)
                })
            Write-GuiLog ("Started {0} minute {1} session for {2}." -f $minutes.Value, $(if ($isHardBlock) { "hard-block" } else { "normal" }), ($selectedApps -join ", "))
            Update-GuiStatus
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, "Could not start session", "OK", "Error")
        }
    })

    $stopButton.Add_Click({
        try {
            Stop-Session
            Write-GuiLog "Normal session ended. Apps are unlocked."
            Update-GuiStatus
        }
        catch {
            [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, "Session is locked", "OK", "Warning")
        }
    })

    $refreshButton.Add_Click({
        Update-GuiStatus
        Write-GuiLog "Status refreshed."
    })

    $form.Add_Shown({
        Write-GuiLog "Ready. Steam is selected by default."
        Update-GuiStatus
        $timer.Start()
    })

    $form.Add_FormClosing({
        $state = Get-State
        if ($state.active -and -not (Test-SessionExpired $state)) {
            $answer = [System.Windows.Forms.MessageBox]::Show("Closing this window stops app monitoring. Keep the window open during a session. Close anyway?", "Monitoring will stop", "YesNo", "Warning")
            if ($answer -eq [System.Windows.Forms.DialogResult]::No) {
                $_.Cancel = $true
                return
            }
        }
        $timer.Stop()
    })

    [void]$form.ShowDialog()
}

switch ($Command) {
    "gui" { Show-Gui }
    "start" { Start-Session $Minutes $HardBlock $Apps }
    "stop" { Stop-Session }
    "status" { Show-Status }
    "monitor" { Monitor-Session }
    "list-apps" { Show-Applications }
}