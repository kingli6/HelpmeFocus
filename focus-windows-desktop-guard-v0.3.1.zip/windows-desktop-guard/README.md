# Focus Desktop Guard for Windows

Block distracting Windows applications during a timed focus session.

Focus Desktop Guard is a small, local Windows companion for the Focus browser extensions. It can monitor applications such as Steam, Discord, Spotify, Epic Games Launcher, and Battle.net, close them during a session, and close them again if they are reopened.

> [!IMPORTANT]
> This version must remain open during a focus session. Closing the Focus Desktop Guard window stops monitoring. It is designed for personal focus and is not tamper-proof.

## Features

- Simple graphical interface
- Choose a session length from **1–240 minutes**
- Select one or more applications to block
- **Normal sessions** can end early
- **Hard-block sessions** stay locked until the timer expires
- Add any Windows program through an `.exe` file picker
- Remove custom applications from the interface
- Local configuration with no account, server, or internet connection required
- Optional command-line controls for advanced users

## Requirements

- Windows 10 or Windows 11
- Windows PowerShell 5.1, included with Windows
- Administrator permission may be required to close applications running with elevated permissions

## Quick start

### 1. Download the program

Download the latest Windows package from the project's **Releases** page:

```text
focus-windows-desktop-guard-v0.3.1.zip
```

You can also download or clone this repository and use the `windows-desktop-guard` folder.

### 2. Unblock the download

Before extracting the ZIP:

1. Right-click the downloaded ZIP file.
2. Choose **Properties**.
3. On the **General** tab, check **Unblock** if it appears.
4. Click **Apply**, then **OK**.
5. Extract the ZIP.

This prevents Windows from applying its downloaded-file security mark to the extracted PowerShell script.

### 3. Start the graphical interface

1. Open the extracted `windows-desktop-guard` folder.
2. Right-click `Start-FocusDesktopGuard.cmd`.
3. Choose **Run as administrator**.

The Focus Desktop Guard window should open. You do not need to open PowerShell or use the command menu.

### 4. Start a session

1. Set the duration in minutes. The default is **25 minutes**.
2. Select the applications to block. **Steam** is selected by default.
3. Choose one:
   - **Normal — can end early**
   - **Hard block — locked timer**
4. Click **Start session**.

The monitor will close selected applications that are currently running and will close them again if they are launched during the session.

Keep the Focus Desktop Guard window open until the session ends.

## Normal sessions and hard-block sessions

### Normal session

A normal session allows an early stop:

1. Click **End normal session**.
2. The selected applications become available immediately.

### Hard-block session

A hard-block session cannot be ended early through the interface:

- The stop button is disabled and shows **Locked until timer ends**.
- The selected applications remain blocked until the countdown reaches zero.
- When the timer expires, the applications are unlocked automatically.

> [!WARNING]
> Hard block only protects the timer while the monitor is running. Closing the window, stopping the process, or uninstalling the program bypasses this first version.

## Add any application

You can add a program without editing `config.json`.

1. Make sure no focus session is active.
2. Click **Add application**.
3. Enter the name you want displayed in the app list.
4. Click **Browse...**.
5. Select the program's `.exe` file.
6. Click **Add application**.

The program will immediately appear in the application checklist and will be saved for future sessions.

### Finding the correct `.exe`

If you do not know which file starts the program:

1. Open the program.
2. Press **Ctrl + Shift + Esc** to open **Task Manager**.
3. Open the **Details** tab.
4. Find the running program.
5. Use the **Add application** file picker to select that `.exe`.

For example:

```text
Notepad.exe  →  select notepad.exe
Discord.exe  →  select Discord.exe
Spotify.exe  →  select Spotify.exe
```

The guard automatically derives the process name from the selected file.

### Remove a custom application

1. Select the custom application in the list.
2. Click **Remove custom**.
3. Confirm the removal.

Built-in presets such as Steam and Discord cannot be removed.

> [!NOTE]
> Some applications use a launcher plus separate helper or game processes. If blocking the main `.exe` does not stop the application, add the helper or game `.exe` as another custom application.

## Built-in application presets

| Display name | Preset | Processes included |
| --- | --- | --- |
| Steam | `steam` | `steam`, `steamwebhelper`, `gameoverlayui` |
| Discord | `discord` | `Discord`, `DiscordPTB`, `DiscordCanary` |
| Spotify | `spotify` | `Spotify` |
| Epic Games Launcher | `epic` | `EpicGamesLauncher`, `EpicWebHelper` |
| Battle.net | `battlenet` | `Battle.net`, `Agent`, `AgentSwitcher` |

## Troubleshooting

### Windows says “Windows protected your PC”

This is usually SmartScreen warning about an unsigned local script.

1. Confirm that you downloaded the package from the intended project source.
2. Click **More info**.
3. Review the displayed file and publisher information.
4. If it is the expected Focus Desktop Guard package, choose **Run anyway**.

You can also use the included `.cmd` launcher after unblocking the ZIP.

### Windows says scripts are disabled

Right-click `Start-FocusDesktopGuard.cmd` and choose **Run as administrator**. The launcher starts PowerShell with a one-time execution-policy bypass.

If you need to launch it manually, open PowerShell in the `windows-desktop-guard` folder and run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File .\FocusDesktopGuard.ps1 -Command gui
```

### The window opens, but an application does not close

Try the following:

1. Close and reopen Focus Desktop Guard using **Run as administrator**.
2. Confirm that you selected the correct `.exe`.
3. Check whether the application is running under another account or with higher permissions.
4. Add the application's helper or launcher `.exe` as another custom application.

### I closed the window during a session

The current version is a foreground monitor, so closing the window stops enforcement. Reopen the launcher and use **Refresh status** or **monitor** mode to inspect the saved session.

For advanced recovery from PowerShell:

```powershell
.\FocusDesktopGuard.ps1 -Command monitor
```

## Advanced command-line use

The graphical interface is recommended. These commands are optional:

```powershell
# Start a 20-minute normal Steam session
.\FocusDesktopGuard.ps1 -Command start -Minutes 20 -Apps steam

# Start a 20-minute hard-block session for Steam and Discord
.\FocusDesktopGuard.ps1 -Command start -Minutes 20 -HardBlock -Apps steam,discord

# Show the current session status
.\FocusDesktopGuard.ps1 -Command status

# End an active normal session
.\FocusDesktopGuard.ps1 -Command stop

# List available application presets
.\FocusDesktopGuard.ps1 -Command list-apps

# Resume monitoring a saved active session
.\FocusDesktopGuard.ps1 -Command monitor
```

## Data and privacy

- The program runs locally on your Windows computer.
- It does not require an account or network connection.
- Applications are stored in the local `config.json` file.
- The active session is stored locally in `state.json`.
- `state.json` is created after the first session and should not be uploaded publicly.

## Limitations

- The monitor window must stay open during a session.
- This version is not a Windows service.
- It is not tamper-proof.
- An administrator can stop the process, change permissions, uninstall the program, or boot into another environment.
- The program closes processes; it does not uninstall, delete, or modify applications.
- Some applications may restart through a launcher or helper process.
- Steam games have their own executable names. Blocking `steam.exe` does not automatically block every game.
- This companion blocks native Windows applications only. Website blocking remains separate in the Firefox and Chrome extensions.

## License and source

This companion is part of the Focus project. See the repository root for the project's license and the Firefox/Chrome extension documentation.