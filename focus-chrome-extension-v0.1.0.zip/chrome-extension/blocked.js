chrome.runtime.sendMessage({ type: "getState" }, (state) => {
  if (!chrome.runtime.lastError && state?.appUrl) {
    document.getElementById("dashboard").href = state.appUrl;
  }
});