(function () {
  let state = null;
  let overlay = null;
  let lastUrl = location.href;

  chrome.runtime.sendMessage({ type: "getState" }, (response) => {
    if (chrome.runtime.lastError || !response) return;
    state = response;
    applyProtection();
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "stateUpdated") {
      state = message.state;
      applyProtection();
    }
  });

  const observer = new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      removeOverlay();
    }
    applyProtection();
  });

  observer.observe(document.documentElement, { childList: true, subtree: true });
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      removeOverlay();
    }
    applyProtection();
  }, 1000);

  function applyProtection() {
    if (!state?.activeSession) {
      removeOverlay();
      return;
    }

    const currentRule = (state.sites || []).find(
      (site) => site.isEnabled !== false && matchesDomain(site.domain, location.hostname),
    );
    if (!currentRule) {
      removeOverlay();
      return;
    }

    if (currentRule.blockType === "full" || isFeedPage(location.hostname, location.pathname)) {
      showOverlay(currentRule.label || currentRule.domain, state.appUrl);
      return;
    }

    if (isYouTube(location.hostname)) {
      hideYouTubeDiscovery();
    }
    removeOverlay();
  }

  function showOverlay(label, appUrl) {
    if (!document.documentElement) return;
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "focus-browser-guard-overlay";
      overlay.innerHTML = `
        <div class="focus-guard-card">
          <div class="focus-guard-mark">F</div>
          <p class="focus-guard-kicker">FOCUS SESSION ACTIVE</p>
          <h1>Stay with the work</h1>
          <p class="focus-guard-copy"></p>
          <a class="focus-guard-link" target="_blank" rel="noopener">Open local dashboard</a>
        </div>
      `;
      const style = document.createElement("style");
      style.textContent = `
        #focus-browser-guard-overlay { position: fixed !important; inset: 0 !important; z-index: 2147483647 !important; display: grid !important; place-items: center !important; background: #0b1220 !important; color: #f7f9fc !important; font-family: Inter, ui-sans-serif, system-ui, sans-serif !important; }
        .focus-guard-card { width: min(440px, calc(100vw - 40px)); padding: 42px 34px; border: 1px solid rgba(255,255,255,.12); border-radius: 22px; background: linear-gradient(145deg, #17233a, #0f1829); box-shadow: 0 24px 80px rgba(0,0,0,.42); text-align: center; }
        .focus-guard-mark { display: grid; place-items: center; width: 48px; height: 48px; margin: 0 auto 20px; border-radius: 14px; background: #8bd3dd; color: #0b1220; font-size: 24px; font-weight: 800; }
        .focus-guard-kicker { margin: 0 0 10px; color: #8bd3dd; font-size: 11px; font-weight: 800; letter-spacing: .16em; }
        .focus-guard-card h1 { margin: 0; font-size: 30px; letter-spacing: -.04em; }
        .focus-guard-copy { margin: 14px 0 24px; color: #b8c3d5; line-height: 1.6; }
        .focus-guard-link { color: #0b1220; background: #f7c873; border-radius: 10px; display: inline-block; padding: 11px 16px; font-size: 14px; font-weight: 750; text-decoration: none; }
      `;
      overlay.appendChild(style);
      document.documentElement.appendChild(overlay);
    }

    overlay.querySelector(".focus-guard-copy").textContent =
      `${label} is paused until your focus session ends. Search and direct links may still be available.`;
    overlay.querySelector(".focus-guard-link").href = appUrl || "#";
  }

  function removeOverlay() {
    if (overlay) {
      overlay.remove();
      overlay = null;
    }
  }

  function isFeedPage(hostname, pathname) {
    const path = pathname.replace(/\/+$/, "") || "/";
    if (isYouTube(hostname)) {
      return path === "/" || path === "/feed/subscriptions" || path === "/feed/trending" || path.startsWith("/shorts");
    }
    if (isTwitter(hostname)) {
      return path === "/" || path === "/home" || path.startsWith("/explore") || path.startsWith("/notifications") || path.startsWith("/messages") || path.startsWith("/i/bookmarks") || path.startsWith("/i/lists");
    }
    if (isReddit(hostname)) {
      return path === "/" || path === "/home" || path.startsWith("/r/all") || path.startsWith("/r/popular") || path.startsWith("/best");
    }
    return path === "/";
  }

  function hideYouTubeDiscovery() {
    if (document.getElementById("focus-youtube-discovery-style")) return;
    const style = document.createElement("style");
    style.id = "focus-youtube-discovery-style";
    style.textContent = `ytd-watch-next-secondary-results-renderer, ytd-reel-shelf-renderer, ytd-rich-grid-renderer, ytd-rich-section-renderer, #related, #secondary { display: none !important; }`;
    (document.head || document.documentElement).appendChild(style);
  }

  function matchesDomain(domain, hostname) {
    const normalized = String(domain || "").toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0];
    return hostname === normalized || hostname.endsWith(`.${normalized}`);
  }

  function isYouTube(hostname) { return hostname === "youtube.com" || hostname.endsWith(".youtube.com"); }
  function isTwitter(hostname) { return hostname === "twitter.com" || hostname.endsWith(".twitter.com") || hostname === "x.com" || hostname.endsWith(".x.com"); }
  function isReddit(hostname) { return hostname === "reddit.com" || hostname.endsWith(".reddit.com"); }
})();