const STATE_KEY = "focusLocalState";
const SESSION_ALARM = "focus-session-check";
const RULE_ID_BASE = 1000;

const DISTRACTION_PRESETS = [
  { key: "youtube", domain: "youtube.com", label: "YouTube", blockType: "feed_only", note: "Feed only" },
  { key: "reddit", domain: "reddit.com", label: "Reddit", blockType: "feed_only", note: "Feed only" },
  { key: "x", domain: "x.com", label: "X / Twitter", blockType: "feed_only", note: "Feed only" },
  { key: "instagram", domain: "instagram.com", label: "Instagram", blockType: "full", note: "Full site" },
  { key: "tiktok", domain: "tiktok.com", label: "TikTok", blockType: "full", note: "Full site" },
  { key: "facebook", domain: "facebook.com", label: "Facebook", blockType: "full", note: "Full site" },
  { key: "netflix", domain: "netflix.com", label: "Netflix", blockType: "full", note: "Full site" },
  { key: "twitch", domain: "twitch.tv", label: "Twitch", blockType: "full", note: "Full site" }
];

const EMPTY_STATE = {
  activeSession: null,
  sites: [],
  syncedAt: null,
  lastError: null
};

let currentState = EMPTY_STATE;
const stateReady = loadState();

chrome.runtime.onInstalled.addListener(async () => {
  await stateReady;
  await ensureAlarm();
  await updateBlockingRules();
});

chrome.runtime.onStartup.addListener(async () => {
  await stateReady;
  await ensureAlarm();
  await expireSessionIfNeeded();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === SESSION_ALARM) {
    await stateReady;
    await expireSessionIfNeeded();
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message)
    .then(sendResponse)
    .catch((reason) => {
      sendResponse({
        ...getClientState(),
        lastError: reason instanceof Error ? reason.message : "The extension could not update."
      });
    });
  return true;
});

async function handleMessage(message) {
  await stateReady;
  switch (message?.type) {
    case "getState":
    case "syncNow":
      await expireSessionIfNeeded();
      return getClientState();
    case "startSession":
      return startSession(message.durationMinutes, message.hardBlock);
    case "stopSession":
      return stopSession();
    case "addSite":
      return addSite(message);
    case "addPreset":
      return addPreset(message.key);
    case "toggleSite":
      return toggleSite(message.id, message.isEnabled);
    case "updateSiteBlockType":
      return updateSiteBlockType(message.id, message.blockType);
    case "deleteSite":
      return deleteSite(message.id);
    default:
      return getClientState();
  }
}

async function loadState() {
  const stored = (await chrome.storage.local.get(STATE_KEY))[STATE_KEY];
  currentState = normalizeState(stored || EMPTY_STATE);
}

async function ensureAlarm() {
  await chrome.alarms.create(SESSION_ALARM, { periodInMinutes: 1 });
}

async function startSession(durationMinutes, hardBlock) {
  await expireSessionIfNeeded();
  if (currentState.activeSession) {
    throw new Error("A focus session is already active.");
  }

  const minutes = Math.max(1, Math.min(240, Number(durationMinutes) || 25));
  const now = Date.now();
  currentState = {
    ...currentState,
    activeSession: {
      id: String(now),
      durationMinutes: minutes,
      hardBlock: Boolean(hardBlock),
      startedAt: new Date(now).toISOString(),
      endsAt: new Date(now + minutes * 60_000).toISOString()
    },
    lastError: null
  };
  await persistAndBroadcast();
  return getClientState();
}

async function stopSession() {
  await expireSessionIfNeeded();
  if (
    currentState.activeSession?.hardBlock &&
    new Date(currentState.activeSession.endsAt).getTime() > Date.now()
  ) {
    throw new Error("Hard block is active. This session cannot end early.");
  }

  currentState = { ...currentState, activeSession: null, lastError: null };
  await persistAndBroadcast();
  return getClientState();
}

async function addSite(message) {
  const domain = normalizeDomain(message.domain);
  if (!domain || !domain.includes(".")) {
    throw new Error("Enter a domain such as reddit.com.");
  }

  const site = {
    id: String(Date.now()),
    domain,
    label: String(message.label || domain).trim() || domain,
    blockType: message.blockType === "feed_only" ? "feed_only" : "full",
    isEnabled: true
  };

  currentState = {
    ...currentState,
    sites: [...currentState.sites.filter((item) => item.domain !== domain), site],
    lastError: null
  };
  await persistAndBroadcast();
  return getClientState();
}

async function addPreset(key) {
  const preset = DISTRACTION_PRESETS.find((item) => item.key === String(key));
  if (!preset) {
    throw new Error("That distraction preset is not available.");
  }
  return addSite(preset);
}

async function toggleSite(id, isEnabled) {
  currentState = {
    ...currentState,
    sites: currentState.sites.map((site) =>
      site.id === String(id) ? { ...site, isEnabled: Boolean(isEnabled) } : site
    )
  };
  await persistAndBroadcast();
  return getClientState();
}

async function updateSiteBlockType(id, blockType) {
  const normalizedType = blockType === "feed_only" ? "feed_only" : "full";
  if (!currentState.sites.some((item) => item.id === String(id))) {
    throw new Error("That site is no longer in your blocklist.");
  }

  currentState = {
    ...currentState,
    sites: currentState.sites.map((item) =>
      item.id === String(id) ? { ...item, blockType: normalizedType } : item
    ),
    lastError: null
  };
  await persistAndBroadcast();
  return getClientState();
}

async function deleteSite(id) {
  currentState = {
    ...currentState,
    sites: currentState.sites.filter((site) => site.id !== String(id))
  };
  await persistAndBroadcast();
  return getClientState();
}

async function expireSessionIfNeeded() {
  if (
    currentState.activeSession &&
    new Date(currentState.activeSession.endsAt).getTime() <= Date.now()
  ) {
    currentState = { ...currentState, activeSession: null };
    await persistAndBroadcast();
  }
}

async function persistAndBroadcast() {
  currentState.syncedAt = new Date().toISOString();
  await chrome.storage.local.set({ [STATE_KEY]: currentState });
  await updateBlockingRules();
  await broadcastState(currentState);
}

async function updateBlockingRules() {
  const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = existingRules.map((rule) => rule.id);
  const addRules = currentState.activeSession
    ? currentState.sites
        .filter((site) => site.isEnabled !== false && site.blockType === "full")
        .map((site, index) => ({
          id: RULE_ID_BASE + index,
          priority: 100,
          action: {
            type: "redirect",
            redirect: { extensionPath: "/blocked.html" }
          },
          condition: {
            regexFilter: hostRegex(site.domain),
            resourceTypes: ["main_frame"]
          }
        }))
    : [];

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds,
    addRules
  });
}

async function broadcastState(state) {
  const tabs = await chrome.tabs.query({});
  await Promise.all(
    tabs.map(async (tab) => {
      if (!tab.id) return;
      try {
        await chrome.tabs.sendMessage(tab.id, { type: "stateUpdated", state });
      } catch {
        // Pages without the content script are expected.
      }
    })
  );
}

function getClientState() {
  return {
    ...currentState,
    mode: "local",
    appUrl: chrome.runtime.getURL("dashboard.html"),
    distractionPresets: DISTRACTION_PRESETS
  };
}

function normalizeState(state) {
  return {
    ...EMPTY_STATE,
    ...state,
    activeSession: state.activeSession
      ? {
          ...state.activeSession,
          hardBlock: state.activeSession.hardBlock === true
        }
      : null,
    sites: Array.isArray(state.sites)
      ? state.sites.map((site) => ({
          ...site,
          id: String(site.id),
          domain: normalizeDomain(site.domain),
          isEnabled: site.isEnabled !== false
        }))
      : []
  };
}

function normalizeDomain(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .split("/")[0]
    .split("?")[0]
    .split("#")[0];
}

function matchesDomain(domain, hostname) {
  const normalized = normalizeDomain(domain);
  return hostname === normalized || hostname.endsWith(`.${normalized}`);
}

function hostRegex(domain) {
  const escaped = normalizeDomain(domain).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return `^https?://([^./]+\\.)*${escaped}(?::\\d+)?(?:[/?#]|$)`;
}