const sessionTitle = document.getElementById("session-title");
const sessionCopy = document.getElementById("session-copy");
const sessionButton = document.getElementById("session-button");
const duration = document.getElementById("duration");
const sessionMode = document.getElementById("session-mode");
const siteCount = document.getElementById("site-count");
const sitesElement = document.getElementById("sites");
const presetsElement = document.getElementById("presets");
const formMessage = document.getElementById("form-message");

sessionButton.addEventListener("click", async () => {
  if (sessionButton.dataset.active === "true") {
    await send({ type: "stopSession" });
  } else {
    await send({
      type: "startSession",
      durationMinutes: duration.value,
      hardBlock: sessionMode.value === "hard"
    });
  }
});

document.getElementById("site-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const state = await send({
    type: "addSite",
    domain: document.getElementById("domain").value,
    label: document.getElementById("label").value,
    blockType: document.getElementById("block-type").value
  });
  if (state) {
    event.target.reset();
    formMessage.textContent = "Site added locally.";
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "stateUpdated") render(message.state);
});

send({ type: "getState" });

async function send(message) {
  try {
    const state = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(response);
      });
    });
    render(state);
    return state;
  } catch (reason) {
    formMessage.textContent = reason instanceof Error ? reason.message : "Could not update local Focus.";
    return null;
  }
}

function render(state = {}) {
  const active = Boolean(state.activeSession);
  sessionTitle.textContent = active ? "Focus session is active" : "Ready to focus?";
  sessionCopy.textContent = active
    ? state.activeSession.hardBlock
      ? `Hard block is locked until ${new Date(state.activeSession.endsAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}.`
      : `Protection ends at ${new Date(state.activeSession.endsAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}.`
    : "Your settings stay inside Chrome. No server is required.";
  sessionButton.textContent = active
    ? state.activeSession.hardBlock
      ? "Hard block locked"
      : "End session"
    : "Start session";
  sessionButton.dataset.active = String(active);
  sessionButton.disabled = Boolean(state.activeSession?.hardBlock);
  duration.disabled = active;
  sessionMode.disabled = active;
  siteCount.textContent = String((state.sites || []).length);
  renderPresets(state);
  sitesElement.replaceChildren(
    ...(state.sites || []).map((site) => {
      const row = document.createElement("div");
      row.className = "site";
      row.innerHTML = `<div class="site-info"><strong></strong><span></span></div><div class="site-actions"><button class="toggle" type="button"></button><select class="site-block-type" aria-label="Blocking mode"><option value="full">Full site</option><option value="feed_only">Feed only</option></select><button class="delete" type="button">Remove</button></div>`;
      row.querySelector("strong").textContent = site.label;
      row.querySelector(".site-info span").textContent = site.domain;
      const toggle = row.querySelector(".toggle");
      toggle.textContent = site.isEnabled ? "Enabled" : "Disabled";
      toggle.addEventListener("click", () => send({ type: "toggleSite", id: site.id, isEnabled: !site.isEnabled }));
      const blockType = row.querySelector(".site-block-type");
      blockType.value = site.blockType === "feed_only" ? "feed_only" : "full";
      blockType.addEventListener("change", () => send({ type: "updateSiteBlockType", id: site.id, blockType: blockType.value }));
      row.querySelector(".delete").addEventListener("click", () => send({ type: "deleteSite", id: site.id }));
      return row;
    })
  );
}

function renderPresets(state) {
  const existingDomains = new Set((state.sites || []).map((site) => site.domain));
  presetsElement.replaceChildren(
    ...(state.distractionPresets || []).map((preset) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "preset";
      button.disabled = existingDomains.has(preset.domain);
      button.innerHTML = `<strong></strong><span></span>`;
      button.querySelector("strong").textContent = button.disabled ? `${preset.label} added` : `+ ${preset.label}`;
      button.querySelector("span").textContent = button.disabled ? "In your blocklist" : preset.note;
      button.addEventListener("click", () => send({ type: "addPreset", key: preset.key }));
      return button;
    })
  );
}