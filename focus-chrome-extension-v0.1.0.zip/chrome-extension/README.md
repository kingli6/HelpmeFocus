# Focus Browser Guard for Chrome

This folder is the local Chrome build of Focus Browser Guard. It runs entirely inside Chrome: no Replit server, API, GitHub Pages site, or internet connection is required.

## Install in Chrome

1. Download or clone this repository.
2. Open:

   ```text
   chrome://extensions
   ```

3. Turn on **Developer mode**.
4. Click **Load unpacked**.
5. Select the `chrome-extension/` folder.
6. Pin **Focus Browser Guard** from Chrome's Extensions menu.
7. Click the Focus Browser Guard toolbar icon.
8. Click **Open local dashboard**.

## Use the extension

The local dashboard lets you:

- Start normal sessions that can end early.
- Start hard-block sessions that stay locked until the timer expires.
- Choose 20, 25, 45, or 60-minute sessions.
- Quickly add common distracting sites.
- Choose **Full site** or **Feed only**.
- Switch an existing site between Full site and Feed only without removing it.
- Enable, disable, and remove sites.

To test it:

1. Open the dashboard.
2. Click the **Reddit** preset, or add `reddit.com` as **Full site**.
3. Choose a session duration.
4. Start a normal or hard-block session.
5. Open a new tab and visit `https://reddit.com`.

## Important Chrome notes

- The extension is active only while a Focus session is active.
- Chrome stores the session and blocklist locally in extension storage.
- The Chrome and Firefox extensions keep separate local data.
- Reload the extension from `chrome://extensions` after downloading an update.
- Chrome may show a warning that unpacked extensions are for developer use; that is expected for local testing.
- This extension blocks websites only. It does not block Steam or other native desktop applications.