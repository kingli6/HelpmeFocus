const statusDot = document.getElementById("status-dot");
const statusTitle = document.getElementById("status-title");
const statusCopy = document.getElementById("status-copy");
const siteCount = document.getElementById("site-count");
const dashboardLink = document.getElementById("dashboard-link");
const stopButton = document.getElementById("stop-button");
const startControls = document.getElementById("start-controls");
const error = document.getElementById("error");

document.getElementById("start-button").addEventListener("click", async () => {
  await send({
    type: "startSession",
    durationMinutes: document.getElementById("duration").value,
    hardBlock: document.getElementById("session-mode").value === "hard"
  });
});

stopButton.addEventListener("click", async () => {
  await send({ type: "stopSession" });
});

document.getElementById("sync-button").addEventListener("click", async () => {
  await send({ type: "syncNow" });
});

refresh();

async function refresh() {
  await send({ type: "getState" });
}

async function send(message) {
  try {
    const state = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(response);
      });
    });
    render(state);
  } catch (reason) {
    error.hidden = false;
    error.textContent = reason instanceof Error ? reason.message : "The extension could not update.";
  }
}

function render(state = {}) {
  const active = Boolean(state.activeSession);
  statusDot.className = `status-dot ${active ? "active" : ""}`;
  statusTitle.textContent = active ? "Protection is active" : "No active focus session";
  statusCopy.textContent = active
    ? state.activeSession.hardBlock
      ? `Hard block is locked until ${new Date(state.activeSession.endsAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}.`
      : `Blocking is on until ${new Date(state.activeSession.endsAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}.`
    : "Start a session here. No server or internet connection is required.";
  siteCount.textContent = String((state.sites || []).filter((site) => site.isEnabled).length);
  dashboardLink.href = state.appUrl || chrome.runtime.getURL("dashboard.html");
  startControls.hidden = active;
  stopButton.hidden = !active;
  stopButton.disabled = Boolean(state.activeSession?.hardBlock);
  stopButton.textContent = state.activeSession?.hardBlock ? "Hard block locked" : "End session";
  error.hidden = !state.lastError;
  if (state.lastError) error.textContent = state.lastError;
}