# Focus Browser Guard for Firefox

This folder is the Firefox build of Focus Browser Guard (version 0.4.0). It is self-contained: the focus timer, blocklist, and dashboard run inside Firefox, with no Replit server, API, GitHub Pages site, or other hosting service required.

## Temporary installation for testing

1. Download or clone the GitHub repository.
2. In Firefox, open `about:debugging#/runtime/this-firefox`.
3. Click **Load Temporary Add-on…**.
4. Select `firefox-extension/manifest.json`.
5. Firefox adds **Focus Browser Guard**.

## Finding the Focus popup

The Focus popup is not the general Firefox Extensions menu:

1. Click Firefox's puzzle-piece **Extensions** button near the address bar.
2. Find **Focus Browser Guard**. Ignore other extensions such as YouTube Repeat.
3. Pin **Focus Browser Guard** to the toolbar.
4. Click the Focus Browser Guard toolbar icon itself.
5. Click **Start focus session** or **Open local dashboard**.

If the popup is empty or shows only a thin white line, remove the temporary add-on from `about:debugging`, load `firefox-extension/manifest.json` again, and click the Focus Browser Guard icon—not the puzzle-piece menu.

## Test the complete flow

1. Open the Focus Browser Guard popup.
2. Click **Open local dashboard**.
3. Add `reddit.com` as **Full Site**.
4. Choose a duration such as **20 minutes**.
5. Choose **Normal** to allow early exit, or **Hard block** to lock the timer.
6. Open a new tab and visit `https://reddit.com`.
7. The Focus blocked page should appear.

The extension is inactive whenever there is no active Focus session.

Temporary add-ons are removed when Firefox restarts. For a permanent install, the extension must be signed by Mozilla and distributed through addons.mozilla.org or another Firefox-approved signing/distribution path. A GitHub repository can host the source and release files, but Firefox will not permanently install an unsigned extension.

## Supported behavior

- Full-site blocklist rules redirect blocked browser pages.
- Feed-only rules protect home/discovery pages for YouTube, Twitter/X, and Reddit.
- YouTube search and direct video pages remain available when YouTube is `feed_only`.
- Session and blocklist data are stored locally inside Firefox.
- Quick-add presets are available for common distracting sites.
- Each saved site has an inline mode selector so you can switch between full-site and feed-only blocking without removing it.
- Normal sessions can end early; hard-block sessions cannot be ended early before their timer expires.
- Protection is active only during an active Focus session.

This browser extension does not control native desktop applications such as Steam. That requires a separate desktop companion.

## GitHub and hosting

The Firefox package is ready to share through GitHub. GitHub is used for source and downloads, not as a required runtime server. GitHub Pages is unnecessary for this local build.

The Replit workspace currently has only its internal backup remote and does not have a GitHub `origin`, so it has not been pushed automatically. Connect GitHub in Replit's Git pane before pushing this repository.