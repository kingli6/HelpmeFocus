browser.runtime.sendMessage({ type: "getState" }).then((state) => {
  if (state?.appUrl) document.getElementById("dashboard").href = state.appUrl;
});