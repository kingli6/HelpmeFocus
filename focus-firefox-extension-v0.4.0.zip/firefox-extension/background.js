const STATE_KEY = "focusLocalState";
const SESSION_ALARM = "focus-session-check";
const EXTENSION_URL = browser.runtime.getURL("");

const DISTRACTION_PRESETS = [
  { key: "youtube", domain: "youtube.com", label: "YouTube", blockType: "feed_only", note: "Feed only" },
  { key: "reddit", domain: "reddit.com", label: "Reddit", blockType: "feed_only", note: "Feed only" },
  { key: "x", domain: "x.com", label: "X / Twitter", blockType: "feed_only", note: "Feed only" },
  { key: "instagram", domain: "instagram.com", label: "Instagram", blockType: "full", note: "Full site" },
  { key: "tiktok", domain: "tiktok.com", label: "TikTok", blockType: "full", note: "Full site" },
  { key: "facebook", domain: "facebook.com", label: "Facebook", blockType: "full", note: "Full site" },
  { key: "netflix", domain: "netflix.com", label: "Netflix", blockType: "full", note: "Full site" },
  { key: "twitch", domain: "twitch.tv", label: "Twitch", blockType: "full", note: "Full site" },
];

const EMPTY_STATE = {
  activeSession: null,
  sites: [],
  syncedAt: null,
  lastError: null,
};

let currentState = EMPTY_STATE;

browser.storage.local.get(STATE_KEY).then(({ [STATE_KEY]: state }) => {
  currentState = normalizeState(state || EMPTY_STATE);
  expireSessionIfNeeded();
});

browser.runtime.onInstalled.addListener(async () => {
  const stored = (await browser.storage.local.get(STATE_KEY))[STATE_KEY];
  currentState = normalizeState(stored || EMPTY_STATE);
  if (!stored) {
    await persistState(currentState);
  }
  await browser.alarms.create(SESSION_ALARM, { periodInMinutes: 1 });
});

browser.runtime.onStartup.addListener(async () => {
  currentState = normalizeState(
    (await browser.storage.local.get(STATE_KEY))[STATE_KEY] || EMPTY_STATE,
  );
  await browser.alarms.create(SESSION_ALARM, { periodInMinutes: 1 });
  await expireSessionIfNeeded();
});

browser.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === SESSION_ALARM) {
    await expireSessionIfNeeded();
  }
});

browser.webRequest.onBeforeRequest.addListener(
  (request) => {
    if (!currentState.activeSession || !request.url || request.url.startsWith(EXTENSION_URL)) {
      return {};
    }

    let hostname;
    try {
      hostname = new URL(request.url).hostname;
    } catch {
      return {};
    }

    const blocked = currentState.sites.some(
      (site) =>
        site.isEnabled !== false &&
        site.blockType === "full" &&
        matchesDomain(site.domain, hostname),
    );

    return blocked ? { redirectUrl: browser.runtime.getURL("blocked.html") } : {};
  },
  { urls: ["<all_urls>"], types: ["main_frame"] },
  ["blocking"],
);

browser.runtime.onMessage.addListener((message) => {
  switch (message?.type) {
    case "getState":
      return getClientState();
    case "syncNow":
      return expireSessionIfNeeded().then(() => getClientState());
    case "startSession":
      return startSession(message.durationMinutes, message.hardBlock);
    case "stopSession":
      return stopSession();
    case "addSite":
      return addSite(message);
    case "addPreset":
      return addPreset(message.key);
    case "toggleSite":
      return toggleSite(message.id, message.isEnabled);
    case "updateSiteBlockType":
      return updateSiteBlockType(message.id, message.blockType);
    case "deleteSite":
      return deleteSite(message.id);
    default:
      return undefined;
  }
});

async function startSession(durationMinutes, hardBlock) {
  await expireSessionIfNeeded();
  if (currentState.activeSession) {
    throw new Error("A focus session is already active.");
  }

  const minutes = Math.max(1, Math.min(240, Number(durationMinutes) || 25));
  const now = Date.now();
  currentState = {
    ...currentState,
    activeSession: {
      id: String(now),
      durationMinutes: minutes,
      hardBlock: Boolean(hardBlock),
      startedAt: new Date(now).toISOString(),
      endsAt: new Date(now + minutes * 60_000).toISOString(),
    },
    lastError: null,
  };
  await persistAndBroadcast();
  return getClientState();
}

async function stopSession() {
  await expireSessionIfNeeded();
  if (
    currentState.activeSession?.hardBlock &&
    new Date(currentState.activeSession.endsAt).getTime() > Date.now()
  ) {
    throw new Error("Hard block is active. This session cannot end early.");
  }

  currentState = { ...currentState, activeSession: null, lastError: null };
  await persistAndBroadcast();
  return getClientState();
}

async function addSite(message) {
  const domain = normalizeDomain(message.domain);
  if (!domain || !domain.includes(".")) {
    throw new Error("Enter a domain such as reddit.com.");
  }

  const site = {
    id: String(Date.now()),
    domain,
    label: String(message.label || domain).trim() || domain,
    blockType: message.blockType === "feed_only" ? "feed_only" : "full",
    isEnabled: true,
  };

  currentState = {
    ...currentState,
    sites: [...currentState.sites.filter((item) => item.domain !== domain), site],
    lastError: null,
  };
  await persistAndBroadcast();
  return getClientState();
}

async function addPreset(key) {
  const preset = DISTRACTION_PRESETS.find((item) => item.key === String(key));
  if (!preset) {
    throw new Error("That distraction preset is not available.");
  }
  return addSite(preset);
}

async function toggleSite(id, isEnabled) {
  currentState = {
    ...currentState,
    sites: currentState.sites.map((site) =>
      site.id === String(id) ? { ...site, isEnabled: Boolean(isEnabled) } : site,
    ),
  };
  await persistAndBroadcast();
  return getClientState();
}

async function updateSiteBlockType(id, blockType) {
  const normalizedType = blockType === "feed_only" ? "feed_only" : "full";
  const site = currentState.sites.find((item) => item.id === String(id));
  if (!site) {
    throw new Error("That site is no longer in your blocklist.");
  }

  currentState = {
    ...currentState,
    sites: currentState.sites.map((item) =>
      item.id === String(id) ? { ...item, blockType: normalizedType } : item,
    ),
    lastError: null,
  };
  await persistAndBroadcast();
  return getClientState();
}

async function deleteSite(id) {
  currentState = {
    ...currentState,
    sites: currentState.sites.filter((site) => site.id !== String(id)),
  };
  await persistAndBroadcast();
  return getClientState();
}

async function expireSessionIfNeeded() {
  if (
    currentState.activeSession &&
    new Date(currentState.activeSession.endsAt).getTime() <= Date.now()
  ) {
    currentState = { ...currentState, activeSession: null };
    await persistAndBroadcast();
  }
}

async function persistAndBroadcast() {
  currentState.syncedAt = new Date().toISOString();
  await browser.storage.local.set({ [STATE_KEY]: currentState });
  await broadcastState(currentState);
}

async function persistState(state) {
  currentState = normalizeState(state);
  await browser.storage.local.set({ [STATE_KEY]: currentState });
}

async function getClientState() {
  await expireSessionIfNeeded();
  return {
    ...currentState,
    mode: "local",
    appUrl: browser.runtime.getURL("dashboard.html"),
    distractionPresets: DISTRACTION_PRESETS,
  };
}

async function broadcastState(state) {
  const tabs = await browser.tabs.query({});
  await Promise.all(
    tabs.map(async (tab) => {
      if (!tab.id) return;
      try {
        await browser.tabs.sendMessage(tab.id, { type: "stateUpdated", state });
      } catch {
        // Protected pages and extension pages may not accept messages.
      }
    }),
  );
}

function normalizeState(state) {
  return {
    ...EMPTY_STATE,
    ...state,
    activeSession: state.activeSession
      ? {
          ...state.activeSession,
          hardBlock: state.activeSession.hardBlock === true,
        }
      : null,
    sites: Array.isArray(state.sites)
      ? state.sites.map((site) => ({
          ...site,
          id: String(site.id),
          domain: normalizeDomain(site.domain),
          isEnabled: site.isEnabled !== false,
        }))
      : [],
  };
}

function normalizeDomain(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .split("/")[0]
    .split("?")[0]
    .split("#")[0];
}

function matchesDomain(domain, hostname) {
  const normalized = normalizeDomain(domain);
  return hostname === normalized || hostname.endsWith(`.${normalized}`);
}